import {Component} from '@angular/Core';
import {Router} from '@angular/router';

@Component({
    selector:'summary',
    templateUrl:'/summary.html'
})

export class SummaryComponent{

    constructor(private router:Router){

    }
}