import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';

@Component ({
  selector: 'scan',
  templateUrl: './scan.html'
})

export class ScanComponent {
 
 
  scanButton= function(){
    this.router.navigate(['/appDetails']);
  }
  

  constructor(private router: Router) {
  }

  

}