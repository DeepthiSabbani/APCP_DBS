import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component ({
  selector: 'appDetails',
  templateUrl: './confirmDetails.html'
})

export class confirmDetailsComponent {

  constructor(private router: Router) {
  }

}