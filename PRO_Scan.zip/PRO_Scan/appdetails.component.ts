import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component ({
  selector: 'appDetails',
  templateUrl: './appdetails.html'
})

export class AppDetailsComponent {

  constructor(private router: Router) {
  }

}